# petstore-api-management
DEMO for pets API management on OCI using terraform and Resource Management